import { CONCESSION_COMBOS } from "@/lib/mockData";

/* ------------------------------------------------------------------ */
/* Kiểu dữ liệu                                                        */
/* ------------------------------------------------------------------ */

export type DiscountType = "PERCENTAGE" | "FIXED";

export interface VoucherItem {
  id: string;
  code: string;
  description: string;
  discountType: DiscountType;
  /** PERCENTAGE: số phần trăm (vd 20). FIXED: số tiền VND (vd 50000). */
  discountValue: number;
  /** Giá trị đơn hàng tối thiểu để áp mã (0 = không giới hạn). */
  minOrderAmount: number;
  /** Số tiền giảm tối đa (0 = không giới hạn). Chủ yếu dùng cho PERCENTAGE. */
  maxDiscountAmount: number;
  /** Tổng số lượt dùng cho phép (0 = không giới hạn). */
  usageLimit: number;
  usedCount: number;
  /** Định dạng YYYY-MM-DD (hoặc ISO đầy đủ). */
  startDate: string;
  endDate: string;
  isActive: boolean;
}

type ConcessionCombo = (typeof CONCESSION_COMBOS)[number];

export interface FnbComboItem extends ConcessionCombo {
  inStock: boolean;
  allowAtSeatDelivery: boolean;
  popcornFlavors: string[];
}

export type NewVoucherInput = Omit<VoucherItem, "id" | "usedCount"> & {
  usedCount?: number;
};

export type NewFnbInput = Omit<ConcessionCombo, "id"> &
  Partial<Pick<FnbComboItem, "inStock" | "allowAtSeatDelivery" | "popcornFlavors">>;

export interface VoucherApplyResult {
  valid: boolean;
  message: string;
  orderAmount: number;
  discountAmount: number;
  finalAmount: number;
  voucher?: VoucherItem;
}

/* ------------------------------------------------------------------ */
/* Dữ liệu mẫu                                                         */
/* ------------------------------------------------------------------ */

function seedVouchers(): VoucherItem[] {
  return [
    {
      id: "vc-sinhvien20",
      code: "SINHVIEN20",
      description: "Giảm 20% cho sinh viên, tối đa 40.000 ₫",
      discountType: "PERCENTAGE",
      discountValue: 20,
      minOrderAmount: 0,
      maxDiscountAmount: 40000,
      usageLimit: 500,
      usedCount: 128,
      startDate: "2026-01-01",
      endDate: "2027-06-30",
      isActive: true,
    },
    {
      id: "vc-beta50k",
      code: "BETA50K",
      description: "Giảm 50.000 ₫ cho đơn từ 150.000 ₫",
      discountType: "FIXED",
      discountValue: 50000,
      minOrderAmount: 150000,
      maxDiscountAmount: 0,
      usageLimit: 200,
      usedCount: 64,
      startDate: "2026-01-01",
      endDate: "2027-06-30",
      isActive: true,
    },
    {
      id: "vc-cinemax2026",
      code: "CINEMAX2026",
      description: "Giảm 30.000 ₫ cho mọi đơn hàng",
      discountType: "FIXED",
      discountValue: 30000,
      minOrderAmount: 0,
      maxDiscountAmount: 0,
      usageLimit: 1000,
      usedCount: 312,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      isActive: true,
    },
    {
      id: "vc-combo15",
      code: "COMBO15",
      description: "Giảm 15% tổng đơn khi mua kèm combo bắp nước",
      discountType: "PERCENTAGE",
      discountValue: 15,
      minOrderAmount: 0,
      maxDiscountAmount: 0,
      usageLimit: 300,
      usedCount: 47,
      startDate: "2026-01-01",
      endDate: "2027-06-30",
      isActive: true,
    },
  ];
}

function seedFnbItems(): FnbComboItem[] {
  return CONCESSION_COMBOS.map((combo) => ({
    ...combo,
    inStock: true,
    allowAtSeatDelivery: true,
    popcornFlavors: ["Caramel", "Phô mai", "Bơ mặn"],
  }));
}

/* ------------------------------------------------------------------ */
/* Kho dữ liệu trong bộ nhớ (giữ nguyên khi hot-reload ở môi trường dev) */
/* ------------------------------------------------------------------ */

interface Store {
  vouchers: VoucherItem[];
  fnbItems: FnbComboItem[];
}

const globalRef = globalThis as unknown as { __cinemaxVoucherFnbStore?: Store };

function getStore(): Store {
  if (!globalRef.__cinemaxVoucherFnbStore) {
    globalRef.__cinemaxVoucherFnbStore = {
      vouchers: seedVouchers(),
      fnbItems: seedFnbItems(),
    };
  }
  return globalRef.__cinemaxVoucherFnbStore;
}

function newId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

function normalizeCode(code: string): string {
  return String(code ?? "").trim().toUpperCase();
}

function startOfDay(value: string): Date {
  return new Date(value.length <= 10 ? `${value}T00:00:00` : value);
}

function endOfDay(value: string): Date {
  return new Date(value.length <= 10 ? `${value}T23:59:59` : value);
}

/* ------------------------------------------------------------------ */
/* Voucher                                                             */
/* ------------------------------------------------------------------ */

export function getVouchers(): VoucherItem[] {
  return getStore().vouchers.map((v) => ({ ...v }));
}

export function createVoucher(input: NewVoucherInput): VoucherItem {
  const store = getStore();
  const code = normalizeCode(input.code);

  if (!code) throw new Error("Mã giảm giá không được để trống.");
  if (store.vouchers.some((v) => v.code === code)) {
    throw new Error(`Mã "${code}" đã tồn tại.`);
  }
  if (input.discountType !== "PERCENTAGE" && input.discountType !== "FIXED") {
    throw new Error("Loại giảm giá không hợp lệ.");
  }
  if (!(input.discountValue > 0)) {
    throw new Error("Giá trị giảm phải lớn hơn 0.");
  }
  if (input.discountType === "PERCENTAGE" && input.discountValue > 100) {
    throw new Error("Giảm theo phần trăm không được vượt quá 100%.");
  }
  if (input.startDate && input.endDate && startOfDay(input.startDate) > endOfDay(input.endDate)) {
    throw new Error("Ngày bắt đầu phải trước ngày kết thúc.");
  }

  const voucher: VoucherItem = {
    id: newId("vc"),
    code,
    description: String(input.description ?? "").trim(),
    discountType: input.discountType,
    discountValue: Number(input.discountValue),
    minOrderAmount: Math.max(0, Number(input.minOrderAmount) || 0),
    maxDiscountAmount: Math.max(0, Number(input.maxDiscountAmount) || 0),
    usageLimit: Math.max(0, Number(input.usageLimit) || 0),
    usedCount: Math.max(0, Number(input.usedCount) || 0),
    startDate: input.startDate,
    endDate: input.endDate,
    isActive: input.isActive ?? true,
  };

  store.vouchers.unshift(voucher);
  return { ...voucher };
}

export function updateVoucher(
  id: string,
  updates: Partial<Omit<VoucherItem, "id">>
): VoucherItem | null {
  const store = getStore();
  const index = store.vouchers.findIndex((v) => v.id === id);
  if (index === -1) return null;

  const current = store.vouchers[index];
  const next: VoucherItem = { ...current, ...updates, id: current.id };

  next.code = normalizeCode(next.code);
  if (!next.code) throw new Error("Mã giảm giá không được để trống.");
  if (store.vouchers.some((v) => v.id !== id && v.code === next.code)) {
    throw new Error(`Mã "${next.code}" đã tồn tại.`);
  }
  if (next.discountType === "PERCENTAGE" && next.discountValue > 100) {
    throw new Error("Giảm theo phần trăm không được vượt quá 100%.");
  }

  store.vouchers[index] = next;
  return { ...next };
}

export function deleteVoucher(id: string): boolean {
  const store = getStore();
  const before = store.vouchers.length;
  store.vouchers = store.vouchers.filter((v) => v.id !== id);
  return store.vouchers.length < before;
}

/**
 * Kiểm tra và tính tiền giảm cho một mã voucher.
 * Mặc định chỉ kiểm tra (không trừ lượt dùng). Truyền { commit: true }
 * khi đơn hàng đã được xác nhận để tăng usedCount.
 */
export function validateAndApplyVoucher(
  code: string,
  orderAmount: number,
  options: { commit?: boolean } = {}
): VoucherApplyResult {
  const amount = Number(orderAmount);
  const fail = (message: string): VoucherApplyResult => ({
    valid: false,
    message,
    orderAmount: Number.isFinite(amount) ? amount : 0,
    discountAmount: 0,
    finalAmount: Number.isFinite(amount) ? amount : 0,
  });

  if (!Number.isFinite(amount) || amount <= 0) {
    return fail("Giá trị đơn hàng không hợp lệ.");
  }

  const normalized = normalizeCode(code);
  if (!normalized) return fail("Vui lòng nhập mã giảm giá.");

  const store = getStore();
  const voucher = store.vouchers.find((v) => v.code === normalized);

  if (!voucher) return fail("Mã giảm giá không tồn tại.");
  if (!voucher.isActive) return fail("Mã giảm giá đang bị tắt.");

  const now = new Date();
  if (voucher.startDate && now < startOfDay(voucher.startDate)) {
    return fail("Mã giảm giá chưa đến thời gian áp dụng.");
  }
  if (voucher.endDate && now > endOfDay(voucher.endDate)) {
    return fail("Mã giảm giá đã hết hạn.");
  }
  if (amount < voucher.minOrderAmount) {
    return fail(
      `Đơn hàng cần tối thiểu ${voucher.minOrderAmount.toLocaleString("vi-VN")} ₫ để dùng mã này.`
    );
  }
  if (voucher.usageLimit > 0 && voucher.usedCount >= voucher.usageLimit) {
    return fail("Mã giảm giá đã hết lượt sử dụng.");
  }

  let discountAmount =
    voucher.discountType === "PERCENTAGE"
      ? Math.round((amount * voucher.discountValue) / 100)
      : voucher.discountValue;

  if (voucher.maxDiscountAmount > 0) {
    discountAmount = Math.min(discountAmount, voucher.maxDiscountAmount);
  }
  discountAmount = Math.min(discountAmount, amount);

  if (options.commit) voucher.usedCount += 1;

  return {
    valid: true,
    message: `Áp dụng mã ${voucher.code} thành công.`,
    orderAmount: amount,
    discountAmount,
    finalAmount: amount - discountAmount,
    voucher: { ...voucher },
  };
}

/* ------------------------------------------------------------------ */
/* Combo bắp nước (F&B)                                                */
/* ------------------------------------------------------------------ */

export function getFnbItems(): FnbComboItem[] {
  return getStore().fnbItems.map((item) => ({
    ...item,
    popcornFlavors: [...item.popcornFlavors],
  }));
}

export function addFnbItem(input: NewFnbInput): FnbComboItem {
  const name = String(input.name ?? "").trim();
  if (!name) throw new Error("Tên combo không được để trống.");
  if (!(Number(input.price) > 0)) throw new Error("Giá combo phải lớn hơn 0.");

  const item: FnbComboItem = {
    ...(input as Omit<ConcessionCombo, "id">),
    id: newId("fnb"),
    name,
    price: Number(input.price),
    inStock: input.inStock ?? true,
    allowAtSeatDelivery: input.allowAtSeatDelivery ?? true,
    popcornFlavors: input.popcornFlavors ?? [],
  } as FnbComboItem;

  getStore().fnbItems.push(item);
  return { ...item, popcornFlavors: [...item.popcornFlavors] };
}

export function updateFnbItem(
  id: string,
  updates: Partial<Omit<FnbComboItem, "id">>
): FnbComboItem | null {
  const store = getStore();
  const index = store.fnbItems.findIndex((item) => item.id === id);
  if (index === -1) return null;

  const next = { ...store.fnbItems[index], ...updates, id } as FnbComboItem;
  if (!String(next.name ?? "").trim()) throw new Error("Tên combo không được để trống.");
  if (!(Number(next.price) > 0)) throw new Error("Giá combo phải lớn hơn 0.");

  store.fnbItems[index] = next;
  return { ...next, popcornFlavors: [...next.popcornFlavors] };
}

export function deleteFnbItem(id: string): boolean {
  const store = getStore();
  const before = store.fnbItems.length;
  store.fnbItems = store.fnbItems.filter((item) => item.id !== id);
  return store.fnbItems.length < before;
}
