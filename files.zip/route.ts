import { NextRequest, NextResponse } from "next/server";
import { isAdminAuthorized } from "@/lib/adminAuth";
import {
  addFnbItem,
  createVoucher,
  deleteFnbItem,
  deleteVoucher,
  getFnbItems,
  getVouchers,
  updateFnbItem,
  updateVoucher,
  validateAndApplyVoucher,
} from "@/lib/voucherAndFnbStore";

export const dynamic = "force-dynamic";

function errorResponse(message: string, status: number) {
  return NextResponse.json({ error: message }, { status });
}

function unauthorized() {
  return errorResponse("Bạn không có quyền thực hiện thao tác này.", 401);
}

async function readJson(request: NextRequest): Promise<Record<string, any> | null> {
  try {
    const body = await request.json();
    return body && typeof body === "object" ? body : null;
  } catch {
    return null;
  }
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : "Đã xảy ra lỗi không xác định.";
}

/* GET: trả về { vouchers, fnbItems } */
export async function GET() {
  return NextResponse.json({
    vouchers: getVouchers(),
    fnbItems: getFnbItems(),
  });
}

/*
 * POST
 *  - Khách hàng:  { action: "apply", code, orderAmount, commit? }
 *  - Admin:       { type: "voucher", data: {...} }  -> thêm Voucher
 *                 { type: "fnb",     data: {...} }  -> thêm Combo bắp nước
 */
export async function POST(request: NextRequest) {
  const body = await readJson(request);
  if (!body) return errorResponse("Dữ liệu gửi lên không hợp lệ.", 400);

  if (body.action === "apply") {
    const result = validateAndApplyVoucher(
      String(body.code ?? ""),
      Number(body.orderAmount),
      // Chỉ Admin mới được trừ lượt dùng trực tiếp qua API này.
      { commit: body.commit === true && isAdminAuthorized(request) }
    );
    return NextResponse.json(result);
  }

  if (!isAdminAuthorized(request)) return unauthorized();

  try {
    if (body.type === "voucher") {
      const voucher = createVoucher(body.data ?? {});
      return NextResponse.json({ voucher }, { status: 201 });
    }
    if (body.type === "fnb") {
      const fnbItem = addFnbItem(body.data ?? {});
      return NextResponse.json({ fnbItem }, { status: 201 });
    }
    return errorResponse('Thiếu hoặc sai "type" (voucher | fnb).', 400);
  } catch (error) {
    return errorResponse(messageOf(error), 400);
  }
}

/*
 * PUT (Admin): { type: "voucher" | "fnb", id, updates: {...} }
 * Dùng để sửa thông tin, bật/tắt isActive của Voucher,
 * hoặc bật/tắt inStock / allowAtSeatDelivery của Combo bắp nước.
 */
export async function PUT(request: NextRequest) {
  if (!isAdminAuthorized(request)) return unauthorized();

  const body = await readJson(request);
  if (!body) return errorResponse("Dữ liệu gửi lên không hợp lệ.", 400);

  const id = String(body.id ?? "");
  const updates = body.updates && typeof body.updates === "object" ? body.updates : null;
  if (!id || !updates) return errorResponse('Cần có "id" và "updates".', 400);

  try {
    if (body.type === "voucher") {
      const voucher = updateVoucher(id, updates);
      if (!voucher) return errorResponse("Không tìm thấy Voucher.", 404);
      return NextResponse.json({ voucher });
    }
    if (body.type === "fnb") {
      const fnbItem = updateFnbItem(id, updates);
      if (!fnbItem) return errorResponse("Không tìm thấy Combo bắp nước.", 404);
      return NextResponse.json({ fnbItem });
    }
    return errorResponse('Thiếu hoặc sai "type" (voucher | fnb).', 400);
  } catch (error) {
    return errorResponse(messageOf(error), 400);
  }
}

/*
 * DELETE (Admin): /api/vouchers?type=voucher&id=xxx
 * (hoặc gửi JSON body { type, id })
 */
export async function DELETE(request: NextRequest) {
  if (!isAdminAuthorized(request)) return unauthorized();

  const { searchParams } = new URL(request.url);
  let type = searchParams.get("type");
  let id = searchParams.get("id");

  if (!type || !id) {
    const body = await readJson(request);
    type = type ?? (body?.type ? String(body.type) : null);
    id = id ?? (body?.id ? String(body.id) : null);
  }
  if (!type || !id) return errorResponse('Cần có "type" và "id".', 400);

  if (type === "voucher") {
    return deleteVoucher(id)
      ? NextResponse.json({ success: true })
      : errorResponse("Không tìm thấy Voucher.", 404);
  }
  if (type === "fnb") {
    return deleteFnbItem(id)
      ? NextResponse.json({ success: true })
      : errorResponse("Không tìm thấy Combo bắp nước.", 404);
  }
  return errorResponse('"type" phải là voucher hoặc fnb.', 400);
}
