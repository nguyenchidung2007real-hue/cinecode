"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  CheckCircle2,
  Loader2,
  Pencil,
  Plus,
  Search,
  Ticket,
  Trash2,
  Utensils,
  X,
  XCircle,
} from "lucide-react";
import { formatVND } from "@/lib/utils";
import type {
  DiscountType,
  FnbComboItem,
  VoucherApplyResult,
  VoucherItem,
} from "@/lib/voucherAndFnbStore";

/* ------------------------------------------------------------------ */
/* Props & helpers                                                     */
/* ------------------------------------------------------------------ */

interface AdminVouchersAndFnbTabProps {
  /** Header xác thực Admin (nếu dự án của bạn dùng header thay vì cookie). */
  adminHeaders?: Record<string, string>;
}

type SubTab = "voucher" | "fnb";
type StatusFilter = "all" | "active" | "inactive" | "expired";

async function callApi<T = any>(
  method: "GET" | "POST" | "PUT" | "DELETE",
  options: {
    body?: unknown;
    query?: string;
    headers?: Record<string, string>;
  } = {}
): Promise<T> {
  const response = await fetch(`/api/vouchers${options.query ?? ""}`, {
    method,
    credentials: "same-origin",
    cache: "no-store",
    headers: {
      "Content-Type": "application/json",
      ...(options.headers ?? {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.error ?? "Yêu cầu thất bại.");
  return data as T;
}

function isExpired(voucher: VoucherItem): boolean {
  if (!voucher.endDate) return false;
  const end = new Date(voucher.endDate.length <= 10 ? `${voucher.endDate}T23:59:59` : voucher.endDate);
  return end < new Date();
}

const inputClass =
  "w-full rounded-lg border border-white/10 bg-[#0B0C10] px-3 py-2 text-sm text-white placeholder:text-white/30 focus:border-rose-500 focus:outline-none focus:ring-1 focus:ring-rose-500";
const labelClass = "mb-1 block text-xs font-medium text-white/60";
const primaryButton =
  "inline-flex items-center justify-center gap-2 rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-rose-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-400 disabled:cursor-not-allowed disabled:opacity-50";
const ghostButton =
  "inline-flex items-center justify-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-sm text-white/80 transition hover:bg-white/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-400";

function Toggle({
  checked,
  onChange,
  label,
  disabled,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-400 disabled:opacity-50 ${
        checked ? "bg-rose-600" : "bg-white/15"
      }`}
    >
      <span
        className={`inline-block h-5 w-5 rounded-full bg-white transition-transform ${
          checked ? "translate-x-5" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* Component chính                                                     */
/* ------------------------------------------------------------------ */

export default function AdminVouchersAndFnbTab({ adminHeaders }: AdminVouchersAndFnbTabProps) {
  const [subTab, setSubTab] = useState<SubTab>("voucher");
  const [vouchers, setVouchers] = useState<VoucherItem[]>([]);
  const [fnbItems, setFnbItems] = useState<FnbComboItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const showNotice = useCallback((type: "success" | "error", text: string) => {
    setNotice({ type, text });
  }, []);

  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(null), 3500);
    return () => clearTimeout(timer);
  }, [notice]);

  const load = useCallback(async () => {
    try {
      const data = await callApi<{ vouchers: VoucherItem[]; fnbItems: FnbComboItem[] }>("GET");
      setVouchers(data.vouchers);
      setFnbItems(data.fnbItems);
    } catch (error) {
      showNotice("error", error instanceof Error ? error.message : "Không tải được dữ liệu.");
    } finally {
      setLoading(false);
    }
  }, [showNotice]);

  useEffect(() => {
    load();
  }, [load]);

  /* ---------------------------- Voucher ---------------------------- */

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [busyId, setBusyId] = useState<string | null>(null);

  const emptyVoucherForm = {
    code: "",
    description: "",
    discountType: "PERCENTAGE" as DiscountType,
    discountValue: "",
    minOrderAmount: "0",
    maxDiscountAmount: "0",
    usageLimit: "100",
    startDate: new Date().toISOString().slice(0, 10),
    endDate: "",
  };
  const [voucherForm, setVoucherForm] = useState(emptyVoucherForm);
  const [showVoucherForm, setShowVoucherForm] = useState(false);
  const [savingVoucher, setSavingVoucher] = useState(false);

  const filteredVouchers = useMemo(() => {
    const keyword = search.trim().toUpperCase();
    return vouchers.filter((v) => {
      if (keyword && !v.code.includes(keyword)) return false;
      const expired = isExpired(v);
      if (statusFilter === "active") return v.isActive && !expired;
      if (statusFilter === "inactive") return !v.isActive;
      if (statusFilter === "expired") return expired;
      return true;
    });
  }, [vouchers, search, statusFilter]);

  async function toggleVoucher(voucher: VoucherItem) {
    setBusyId(voucher.id);
    try {
      const { voucher: updated } = await callApi<{ voucher: VoucherItem }>("PUT", {
        headers: adminHeaders,
        body: { type: "voucher", id: voucher.id, updates: { isActive: !voucher.isActive } },
      });
      setVouchers((list) => list.map((v) => (v.id === updated.id ? updated : v)));
      showNotice("success", `${updated.code} đã ${updated.isActive ? "được bật" : "được tắt"}.`);
    } catch (error) {
      showNotice("error", error instanceof Error ? error.message : "Không cập nhật được.");
    } finally {
      setBusyId(null);
    }
  }

  async function removeVoucher(voucher: VoucherItem) {
    if (!window.confirm(`Xóa mã ${voucher.code}? Thao tác này không thể hoàn tác.`)) return;
    setBusyId(voucher.id);
    try {
      await callApi("DELETE", {
        headers: adminHeaders,
        query: `?type=voucher&id=${encodeURIComponent(voucher.id)}`,
      });
      setVouchers((list) => list.filter((v) => v.id !== voucher.id));
      showNotice("success", `Đã xóa mã ${voucher.code}.`);
    } catch (error) {
      showNotice("error", error instanceof Error ? error.message : "Không xóa được.");
    } finally {
      setBusyId(null);
    }
  }

  async function submitVoucher(event: React.FormEvent) {
    event.preventDefault();
    setSavingVoucher(true);
    try {
      const { voucher } = await callApi<{ voucher: VoucherItem }>("POST", {
        headers: adminHeaders,
        body: {
          type: "voucher",
          data: {
            code: voucherForm.code,
            description: voucherForm.description,
            discountType: voucherForm.discountType,
            discountValue: Number(voucherForm.discountValue),
            minOrderAmount: Number(voucherForm.minOrderAmount) || 0,
            maxDiscountAmount: Number(voucherForm.maxDiscountAmount) || 0,
            usageLimit: Number(voucherForm.usageLimit) || 0,
            startDate: voucherForm.startDate,
            endDate: voucherForm.endDate,
            isActive: true,
          },
        },
      });
      setVouchers((list) => [voucher, ...list]);
      setVoucherForm(emptyVoucherForm);
      setShowVoucherForm(false);
      showNotice("success", `Đã thêm mã ${voucher.code}.`);
    } catch (error) {
      showNotice("error", error instanceof Error ? error.message : "Không thêm được mã.");
    } finally {
      setSavingVoucher(false);
    }
  }

  /* Test áp mã */
  const [testCode, setTestCode] = useState("");
  const [testAmount, setTestAmount] = useState("200000");
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<VoucherApplyResult | null>(null);

  async function runTest(event: React.FormEvent) {
    event.preventDefault();
    setTesting(true);
    try {
      const result = await callApi<VoucherApplyResult>("POST", {
        body: { action: "apply", code: testCode, orderAmount: Number(testAmount) },
      });
      setTestResult(result);
    } catch (error) {
      showNotice("error", error instanceof Error ? error.message : "Không kiểm tra được mã.");
    } finally {
      setTesting(false);
    }
  }

  /* ------------------------------ F&B ------------------------------ */

  const emptyFnbForm = {
    name: "",
    description: "",
    price: "",
    icon: "🍿",
    badge: "",
    popcornFlavors: "Caramel, Phô mai, Bơ mặn",
    inStock: true,
    allowAtSeatDelivery: true,
  };
  const [fnbForm, setFnbForm] = useState(emptyFnbForm);
  const [editingFnbId, setEditingFnbId] = useState<string | null>(null);
  const [showFnbForm, setShowFnbForm] = useState(false);
  const [savingFnb, setSavingFnb] = useState(false);

  function startEditFnb(item: FnbComboItem) {
    setEditingFnbId(item.id);
    setFnbForm({
      name: item.name,
      description: item.description,
      price: String(item.price),
      icon: item.icon,
      badge: item.badge ?? "",
      popcornFlavors: item.popcornFlavors.join(", "),
      inStock: item.inStock,
      allowAtSeatDelivery: item.allowAtSeatDelivery,
    });
    setShowFnbForm(true);
  }

  function closeFnbForm() {
    setEditingFnbId(null);
    setFnbForm(emptyFnbForm);
    setShowFnbForm(false);
  }

  async function patchFnb(item: FnbComboItem, updates: Partial<FnbComboItem>, successText: string) {
    setBusyId(item.id);
    try {
      const { fnbItem } = await callApi<{ fnbItem: FnbComboItem }>("PUT", {
        headers: adminHeaders,
        body: { type: "fnb", id: item.id, updates },
      });
      setFnbItems((list) => list.map((f) => (f.id === fnbItem.id ? fnbItem : f)));
      showNotice("success", successText);
    } catch (error) {
      showNotice("error", error instanceof Error ? error.message : "Không cập nhật được.");
    } finally {
      setBusyId(null);
    }
  }

  async function removeFnb(item: FnbComboItem) {
    if (!window.confirm(`Xóa combo "${item.name}"?`)) return;
    setBusyId(item.id);
    try {
      await callApi("DELETE", {
        headers: adminHeaders,
        query: `?type=fnb&id=${encodeURIComponent(item.id)}`,
      });
      setFnbItems((list) => list.filter((f) => f.id !== item.id));
      showNotice("success", `Đã xóa combo ${item.name}.`);
    } catch (error) {
      showNotice("error", error instanceof Error ? error.message : "Không xóa được.");
    } finally {
      setBusyId(null);
    }
  }

  async function submitFnb(event: React.FormEvent) {
    event.preventDefault();
    setSavingFnb(true);
    const payload = {
      name: fnbForm.name,
      description: fnbForm.description,
      price: Number(fnbForm.price),
      icon: fnbForm.icon || "🍿",
      ...(fnbForm.badge.trim() ? { badge: fnbForm.badge.trim() } : {}),
      popcornFlavors: fnbForm.popcornFlavors
        .split(",")
        .map((flavor) => flavor.trim())
        .filter(Boolean),
      inStock: fnbForm.inStock,
      allowAtSeatDelivery: fnbForm.allowAtSeatDelivery,
    };

    try {
      if (editingFnbId) {
        const { fnbItem } = await callApi<{ fnbItem: FnbComboItem }>("PUT", {
          headers: adminHeaders,
          body: { type: "fnb", id: editingFnbId, updates: { ...payload, badge: fnbForm.badge.trim() || undefined } },
        });
        setFnbItems((list) => list.map((f) => (f.id === fnbItem.id ? fnbItem : f)));
        showNotice("success", `Đã lưu combo ${fnbItem.name}.`);
      } else {
        const { fnbItem } = await callApi<{ fnbItem: FnbComboItem }>("POST", {
          headers: adminHeaders,
          body: { type: "fnb", data: payload },
        });
        setFnbItems((list) => [...list, fnbItem]);
        showNotice("success", `Đã thêm combo ${fnbItem.name}.`);
      }
      closeFnbForm();
    } catch (error) {
      showNotice("error", error instanceof Error ? error.message : "Không lưu được combo.");
    } finally {
      setSavingFnb(false);
    }
  }

  /* ------------------------------ UI ------------------------------- */

  const subTabButton = (id: SubTab, label: string, Icon: typeof Ticket) => (
    <button
      type="button"
      onClick={() => setSubTab(id)}
      aria-pressed={subTab === id}
      className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-400 ${
        subTab === id ? "bg-rose-600 text-white" : "text-white/60 hover:bg-white/5 hover:text-white"
      }`}
    >
      <Icon className="h-4 w-4" />
      {label}
    </button>
  );

  return (
    <section className="space-y-6 bg-[#0B0C10] text-white">
      <div className="flex flex-wrap gap-2 rounded-xl border border-white/10 bg-[#14151B] p-1.5">
        {subTabButton("voucher", "Quản Lý Mã Giảm Giá (Voucher)", Ticket)}
        {subTabButton("fnb", "Quản Lý Bắp Nước (F&B & Giao Tận Ghế)", Utensils)}
      </div>

      {notice && (
        <div
          role="status"
          className={`flex items-center gap-2 rounded-lg border px-4 py-3 text-sm ${
            notice.type === "success"
              ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
              : "border-rose-500/30 bg-rose-500/10 text-rose-300"
          }`}
        >
          {notice.type === "success" ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
          {notice.text}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-[#14151B] py-16 text-white/60">
          <Loader2 className="h-5 w-5 animate-spin" />
          Đang tải dữ liệu...
        </div>
      ) : subTab === "voucher" ? (
        <div className="space-y-6">
          {/* Thanh công cụ */}
          <div className="flex flex-wrap items-center gap-3 rounded-xl border border-white/10 bg-[#14151B] p-4">
            <div className="relative min-w-[220px] flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/40" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Tìm theo mã code..."
                aria-label="Tìm theo mã code"
                className={`${inputClass} pl-9`}
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
              aria-label="Lọc trạng thái"
              className={`${inputClass} w-auto`}
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="active">Đang hoạt động</option>
              <option value="inactive">Đã tắt</option>
              <option value="expired">Đã hết hạn</option>
            </select>
            <button type="button" onClick={() => setShowVoucherForm((s) => !s)} className={primaryButton}>
              {showVoucherForm ? <X className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
              {showVoucherForm ? "Đóng form" : "Thêm voucher"}
            </button>
          </div>

          {/* Form thêm mới */}
          {showVoucherForm && (
            <form
              onSubmit={submitVoucher}
              className="grid gap-4 rounded-xl border border-white/10 bg-[#14151B] p-5 sm:grid-cols-2 lg:grid-cols-3"
            >
              <div>
                <label className={labelClass} htmlFor="vc-code">Mã code</label>
                <input
                  id="vc-code"
                  required
                  value={voucherForm.code}
                  onChange={(e) => setVoucherForm({ ...voucherForm, code: e.target.value.toUpperCase() })}
                  placeholder="VD: SUMMER25"
                  className={inputClass}
                />
              </div>
              <div className="sm:col-span-1 lg:col-span-2">
                <label className={labelClass} htmlFor="vc-desc">Mô tả</label>
                <input
                  id="vc-desc"
                  value={voucherForm.description}
                  onChange={(e) => setVoucherForm({ ...voucherForm, description: e.target.value })}
                  placeholder="Giảm 25% cho vé xem phim mùa hè"
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass} htmlFor="vc-type">Loại giảm giá</label>
                <select
                  id="vc-type"
                  value={voucherForm.discountType}
                  onChange={(e) => setVoucherForm({ ...voucherForm, discountType: e.target.value as DiscountType })}
                  className={inputClass}
                >
                  <option value="PERCENTAGE">Theo phần trăm (%)</option>
                  <option value="FIXED">Số tiền cố định (₫)</option>
                </select>
              </div>
              <div>
                <label className={labelClass} htmlFor="vc-value">
                  Giá trị giảm {voucherForm.discountType === "PERCENTAGE" ? "(%)" : "(₫)"}
                </label>
                <input
                  id="vc-value"
                  type="number"
                  min={1}
                  max={voucherForm.discountType === "PERCENTAGE" ? 100 : undefined}
                  required
                  value={voucherForm.discountValue}
                  onChange={(e) => setVoucherForm({ ...voucherForm, discountValue: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass} htmlFor="vc-min">Đơn tối thiểu (₫)</label>
                <input
                  id="vc-min"
                  type="number"
                  min={0}
                  value={voucherForm.minOrderAmount}
                  onChange={(e) => setVoucherForm({ ...voucherForm, minOrderAmount: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass} htmlFor="vc-max">Giảm tối đa (₫, 0 = không giới hạn)</label>
                <input
                  id="vc-max"
                  type="number"
                  min={0}
                  value={voucherForm.maxDiscountAmount}
                  onChange={(e) => setVoucherForm({ ...voucherForm, maxDiscountAmount: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass} htmlFor="vc-limit">Giới hạn lượt dùng (0 = không giới hạn)</label>
                <input
                  id="vc-limit"
                  type="number"
                  min={0}
                  value={voucherForm.usageLimit}
                  onChange={(e) => setVoucherForm({ ...voucherForm, usageLimit: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass} htmlFor="vc-start">Ngày bắt đầu</label>
                <input
                  id="vc-start"
                  type="date"
                  required
                  value={voucherForm.startDate}
                  onChange={(e) => setVoucherForm({ ...voucherForm, startDate: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass} htmlFor="vc-end">Ngày kết thúc</label>
                <input
                  id="vc-end"
                  type="date"
                  required
                  value={voucherForm.endDate}
                  onChange={(e) => setVoucherForm({ ...voucherForm, endDate: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div className="flex items-end sm:col-span-2 lg:col-span-3">
                <button type="submit" disabled={savingVoucher} className={primaryButton}>
                  {savingVoucher && <Loader2 className="h-4 w-4 animate-spin" />}
                  Lưu voucher
                </button>
              </div>
            </form>
          )}

          {/* Bảng voucher */}
          <div className="overflow-x-auto rounded-xl border border-white/10 bg-[#14151B]">
            <table className="w-full min-w-[760px] text-left text-sm">
              <thead className="border-b border-white/10 text-xs text-white/50">
                <tr>
                  <th className="px-4 py-3 font-medium">Mã</th>
                  <th className="px-4 py-3 font-medium">Ưu đãi</th>
                  <th className="px-4 py-3 font-medium">Điều kiện</th>
                  <th className="px-4 py-3 font-medium">Đã dùng / Giới hạn</th>
                  <th className="px-4 py-3 font-medium">Hiệu lực</th>
                  <th className="px-4 py-3 font-medium">Bật / Tắt</th>
                  <th className="px-4 py-3 text-right font-medium">Xóa</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredVouchers.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-4 py-10 text-center text-white/50">
                      Không có voucher nào khớp. Thử đổi bộ lọc hoặc thêm voucher mới.
                    </td>
                  </tr>
                ) : (
                  filteredVouchers.map((v) => {
                    const expired = isExpired(v);
                    const exhausted = v.usageLimit > 0 && v.usedCount >= v.usageLimit;
                    const percent = v.usageLimit > 0 ? Math.min(100, (v.usedCount / v.usageLimit) * 100) : 0;
                    return (
                      <tr key={v.id} className={busyId === v.id ? "opacity-60" : ""}>
                        <td className="px-4 py-3">
                          <p className="font-mono font-semibold">{v.code}</p>
                          <p className="max-w-[220px] truncate text-xs text-white/50">{v.description}</p>
                        </td>
                        <td className="px-4 py-3">
                          {v.discountType === "PERCENTAGE" ? `${v.discountValue}%` : formatVND(v.discountValue)}
                          {v.maxDiscountAmount > 0 && (
                            <p className="text-xs text-white/50">Tối đa {formatVND(v.maxDiscountAmount)}</p>
                          )}
                        </td>
                        <td className="px-4 py-3 text-white/70">
                          {v.minOrderAmount > 0 ? `Từ ${formatVND(v.minOrderAmount)}` : "Mọi đơn hàng"}
                        </td>
                        <td className="px-4 py-3">
                          <p className={exhausted ? "text-rose-400" : ""}>
                            {v.usedCount} / {v.usageLimit > 0 ? v.usageLimit : "∞"}
                          </p>
                          {v.usageLimit > 0 && (
                            <div className="mt-1 h-1 w-24 overflow-hidden rounded-full bg-white/10">
                              <div className="h-full bg-rose-600" style={{ width: `${percent}%` }} />
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3 text-xs text-white/70">
                          <p>{v.startDate} đến {v.endDate}</p>
                          {expired && <p className="mt-0.5 text-rose-400">Đã hết hạn</p>}
                        </td>
                        <td className="px-4 py-3">
                          <Toggle
                            checked={v.isActive}
                            disabled={busyId === v.id}
                            onChange={() => toggleVoucher(v)}
                            label={`${v.isActive ? "Tắt" : "Bật"} mã ${v.code}`}
                          />
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            type="button"
                            onClick={() => removeVoucher(v)}
                            disabled={busyId === v.id}
                            aria-label={`Xóa mã ${v.code}`}
                            className="rounded-lg p-2 text-white/50 transition hover:bg-rose-500/10 hover:text-rose-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-rose-400"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Test áp mã */}
          <div className="rounded-xl border border-white/10 bg-[#14151B] p-5">
            <h3 className="text-base font-semibold">Test thử áp dụng mã giảm giá</h3>
            <p className="mt-1 text-sm text-white/50">
              Nhập mã và giá trị đơn hàng để xem khách sẽ được giảm bao nhiêu. Thao tác này không trừ lượt dùng.
            </p>
            <form onSubmit={runTest} className="mt-4 flex flex-wrap items-end gap-3">
              <div className="min-w-[180px] flex-1">
                <label className={labelClass} htmlFor="test-code">Mã giảm giá</label>
                <input
                  id="test-code"
                  value={testCode}
                  onChange={(e) => setTestCode(e.target.value.toUpperCase())}
                  placeholder="SINHVIEN20"
                  className={inputClass}
                />
              </div>
              <div className="min-w-[160px]">
                <label className={labelClass} htmlFor="test-amount">Giá trị đơn hàng (₫)</label>
                <input
                  id="test-amount"
                  type="number"
                  min={1}
                  value={testAmount}
                  onChange={(e) => setTestAmount(e.target.value)}
                  className={inputClass}
                />
              </div>
              <button type="submit" disabled={testing} className={primaryButton}>
                {testing && <Loader2 className="h-4 w-4 animate-spin" />}
                Áp dụng thử
              </button>
            </form>

            {testResult && (
              <div
                role="status"
                className={`mt-4 rounded-lg border p-4 text-sm ${
                  testResult.valid
                    ? "border-emerald-500/30 bg-emerald-500/10"
                    : "border-rose-500/30 bg-rose-500/10"
                }`}
              >
                <p className={`flex items-center gap-2 font-semibold ${testResult.valid ? "text-emerald-300" : "text-rose-300"}`}>
                  {testResult.valid ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                  {testResult.message}
                </p>
                {testResult.valid && (
                  <dl className="mt-3 grid max-w-sm grid-cols-2 gap-y-1 text-white/80">
                    <dt>Giá trị đơn hàng</dt>
                    <dd className="text-right">{formatVND(testResult.orderAmount)}</dd>
                    <dt>Số tiền được giảm</dt>
                    <dd className="text-right text-emerald-300">- {formatVND(testResult.discountAmount)}</dd>
                    <dt className="font-semibold text-white">Khách cần trả</dt>
                    <dd className="text-right font-semibold text-white">{formatVND(testResult.finalAmount)}</dd>
                  </dl>
                )}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 bg-[#14151B] p-4">
            <p className="text-sm text-white/60">
              {fnbItems.length} combo, {fnbItems.filter((f) => f.inStock).length} đang còn hàng.
            </p>
            <button
              type="button"
              onClick={() => (showFnbForm ? closeFnbForm() : setShowFnbForm(true))}
              className={primaryButton}
            >
              {showFnbForm ? <X className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
              {showFnbForm ? "Đóng form" : "Thêm combo"}
            </button>
          </div>

          {showFnbForm && (
            <form
              onSubmit={submitFnb}
              className="grid gap-4 rounded-xl border border-white/10 bg-[#14151B] p-5 sm:grid-cols-2 lg:grid-cols-3"
            >
              <h3 className="text-base font-semibold sm:col-span-2 lg:col-span-3">
                {editingFnbId ? "Chỉnh sửa combo" : "Thêm combo mới"}
              </h3>
              <div>
                <label className={labelClass} htmlFor="fnb-name">Tên combo</label>
                <input
                  id="fnb-name"
                  required
                  value={fnbForm.name}
                  onChange={(e) => setFnbForm({ ...fnbForm, name: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass} htmlFor="fnb-price">Giá (₫)</label>
                <input
                  id="fnb-price"
                  type="number"
                  min={1000}
                  step={1000}
                  required
                  value={fnbForm.price}
                  onChange={(e) => setFnbForm({ ...fnbForm, price: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass} htmlFor="fnb-icon">Biểu tượng</label>
                  <input
                    id="fnb-icon"
                    value={fnbForm.icon}
                    onChange={(e) => setFnbForm({ ...fnbForm, icon: e.target.value })}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass} htmlFor="fnb-badge">Nhãn (tùy chọn)</label>
                  <input
                    id="fnb-badge"
                    value={fnbForm.badge}
                    onChange={(e) => setFnbForm({ ...fnbForm, badge: e.target.value })}
                    placeholder="Bán chạy"
                    className={inputClass}
                  />
                </div>
              </div>
              <div className="sm:col-span-2">
                <label className={labelClass} htmlFor="fnb-desc">Mô tả</label>
                <input
                  id="fnb-desc"
                  value={fnbForm.description}
                  onChange={(e) => setFnbForm({ ...fnbForm, description: e.target.value })}
                  placeholder="1 bắp lớn + 2 nước ngọt"
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass} htmlFor="fnb-flavors">Vị bắp (cách nhau bằng dấu phẩy)</label>
                <input
                  id="fnb-flavors"
                  value={fnbForm.popcornFlavors}
                  onChange={(e) => setFnbForm({ ...fnbForm, popcornFlavors: e.target.value })}
                  className={inputClass}
                />
              </div>
              <label className="flex items-center gap-3 text-sm text-white/80">
                <Toggle
                  checked={fnbForm.inStock}
                  onChange={(next) => setFnbForm({ ...fnbForm, inStock: next })}
                  label="Còn hàng"
                />
                Còn hàng
              </label>
              <label className="flex items-center gap-3 text-sm text-white/80">
                <Toggle
                  checked={fnbForm.allowAtSeatDelivery}
                  onChange={(next) => setFnbForm({ ...fnbForm, allowAtSeatDelivery: next })}
                  label="Giao tận ghế"
                />
                Giao tận ghế ngồi
              </label>
              <div className="flex gap-3 sm:col-span-2 lg:col-span-3">
                <button type="submit" disabled={savingFnb} className={primaryButton}>
                  {savingFnb && <Loader2 className="h-4 w-4 animate-spin" />}
                  {editingFnbId ? "Lưu thay đổi" : "Thêm combo"}
                </button>
                <button type="button" onClick={closeFnbForm} className={ghostButton}>
                  Hủy
                </button>
              </div>
            </form>
          )}

          <div className="grid gap-4 md:grid-cols-2">
            {fnbItems.length === 0 && (
              <p className="rounded-xl border border-white/10 bg-[#14151B] p-8 text-center text-white/50 md:col-span-2">
                Chưa có combo nào. Chọn "Thêm combo" để tạo combo đầu tiên.
              </p>
            )}
            {fnbItems.map((item) => (
              <article
                key={item.id}
                className={`rounded-xl border border-white/10 bg-[#14151B] p-5 ${busyId === item.id ? "opacity-60" : ""}`}
              >
                <div className="flex items-start gap-4">
                  <span className="text-4xl" aria-hidden>{item.icon}</span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-semibold">{item.name}</h3>
                      {item.badge && (
                        <span className="rounded-full bg-rose-600/20 px-2 py-0.5 text-xs text-rose-300">{item.badge}</span>
                      )}
                      <span
                        className={`rounded-full px-2 py-0.5 text-xs ${
                          item.inStock ? "bg-emerald-500/15 text-emerald-300" : "bg-white/10 text-white/50"
                        }`}
                      >
                        {item.inStock ? "Còn hàng" : "Tạm hết hàng"}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-white/60">{item.description}</p>
                    <p className="mt-2 text-lg font-semibold text-rose-400">{formatVND(item.price)}</p>
                    {item.popcornFlavors.length > 0 && (
                      <p className="mt-1 text-xs text-white/50">Vị bắp: {item.popcornFlavors.join(", ")}</p>
                    )}
                  </div>
                </div>

                <div className="mt-4 space-y-3 border-t border-white/10 pt-4 text-sm">
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-white/80">Còn hàng / Tạm hết hàng</span>
                    <Toggle
                      checked={item.inStock}
                      disabled={busyId === item.id}
                      label={`Đổi trạng thái còn hàng của ${item.name}`}
                      onChange={(next) =>
                        patchFnb(item, { inStock: next }, `${item.name}: ${next ? "còn hàng" : "tạm hết hàng"}.`)
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-white/80">Giao bắp nước tận ghế ngồi (At-Seat Delivery)</span>
                    <Toggle
                      checked={item.allowAtSeatDelivery}
                      disabled={busyId === item.id}
                      label={`Đổi giao tận ghế của ${item.name}`}
                      onChange={(next) =>
                        patchFnb(
                          item,
                          { allowAtSeatDelivery: next },
                          `${item.name}: ${next ? "đã bật" : "đã tắt"} giao tận ghế.`
                        )
                      }
                    />
                  </div>
                  <div className="flex justify-end gap-2 pt-1">
                    <button type="button" onClick={() => startEditFnb(item)} className={ghostButton}>
                      <Pencil className="h-4 w-4" />
                      Sửa
                    </button>
                    <button
                      type="button"
                      onClick={() => removeFnb(item)}
                      disabled={busyId === item.id}
                      className={`${ghostButton} hover:border-rose-500/40 hover:text-rose-400`}
                    >
                      <Trash2 className="h-4 w-4" />
                      Xóa
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
